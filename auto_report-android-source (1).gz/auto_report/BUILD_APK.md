# Build APK

This is a Flutter project. The Android toolchain versions were updated for current Flutter:

- Gradle wrapper: 8.14
- Android Gradle Plugin: 8.11.1
- Kotlin Gradle Plugin: 2.2.20

On an x86_64 Linux/macOS/Windows build machine with Flutter 3.47.7+, Java 21, and Android SDK 36:

```sh
flutter pub get
flutter build apk --release --build-name=2.6.17 --build-number=96
```

The output will be `build/app/outputs/flutter-apk/app-release.apk`.
