import 'dart:convert';
import 'dart:math';

import 'package:auto_report/banks/aya/data/account/account_data.dart';
import 'package:auto_report/banks/aya/network/sender.dart';
import 'package:auto_report/banks/aya/utils/sentry_header_generator.dart';
import 'package:auto_report/proto/report/response/general_response.dart';
import 'package:auto_report/proto/report/response/get_platforms_response.dart';
import 'package:auto_report/utils/log_helper.dart';
import 'package:auto_report/widges/platform_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart' as http;

class AuthPage extends StatefulWidget {
  final List<GetPlatformsResponseData?>? platforms;
  final String? phoneNumber;
  final String? id;
  final String? pin;
  final String? token;
  final String? remark;

  const AuthPage({
    super.key,
    required this.platforms,
    this.phoneNumber,
    this.id,
    this.pin,
    this.token,
    this.remark,
  });

  @override
  State<AuthPage> createState() => _AuthPageState();
}

enum AyaLoginStaus { none, requestOtp, waitOldDeviceAuth, logined }

class _AuthPageState extends State<AuthPage> {
  String? _phoneNumber;
  String? _id;
  String? _password;
  String? _otpCode;

  String? _token;
  String? _remark;

  GetPlatformsResponseData? _platformsResponseData;

  late Sender _sender;

  final _models = [
    'google Pixel 5',
    'google Pixel 6',
    'google Pixel 5 pro',
    'google Pixel 7',
    'google Pixel 8',
    'google Pixel 9'
  ];
  // final _osVersions = ['12', '13', '14'];

  AyaLoginStaus _loginStatus = AyaLoginStaus.none;
  // bool _hasLogin = false;
  bool _hasAuth = false;

  @override
  void initState() {
    super.initState();

    _phoneNumber = widget.phoneNumber ?? '';
    _id = widget.id ?? '';
    _password = widget.pin ?? '';

    // _token = widget.token ?? '';
    _token = '';
    _remark = widget.remark ?? '';

    if (_token!.isEmpty) {
      final sb = StringBuffer();
      final rand = Random();
      for (var i = 0; i < 32; ++i) {
        if (rand.nextBool()) {
          sb.write(String.fromCharCode(0x61 + rand.nextInt(26)));
        } else {
          sb.write(String.fromCharCode(0x30 + rand.nextInt(10)));
        }
      }
      _token = sb.toString();
    }

    final ran = Random.secure();

    final headers = SentryHeaderGenerator.generateFullMockHeaders();

    final firebaseToken = generateFirebaseTokenLikeExample();
    final deviceId = generateRandomDeviceId();
    // final authorization = headers['Authorization'] ?? '';
    final sentryTrace = headers['Sentry-Trace'] ?? '';
    final baggage = headers['Baggage'] ?? '';

    const authorization = 'Basic hQCOKs75uoYxakySqIA7qrjzdj2Z9PYn';
    // const sentryTrace = '7a90ceee7d324e4782802b7816307af3-927d9bc3208888ee';
    // const baggage = 'sentry-environment=production,sentry-public_key=dc90897854163b60850b69daf43b68e6,sentry-trace_id=7a90ceee7d324e4782802b7816307af3,sentry-org_id=1016539';
    // const deviceId = '9a6eff0b958284b1';
    // const firebaseToken = 'fmmcHmQoTFOsE2s0_Hzb1g:APA91bEoDd411gmspHys0HRIwnfYaHJ-k4RT5CKzFhhgn8LMhu7ednFahZTIy7X0FbN_qo4c6CFaTJxfexHGoR-F1U9oByAnEu9yzGSi2CO1diaiYhIvDps';

    final model = _models[ran.nextInt(_models.length)];

    logger.i("Authorization: $authorization");
    logger.i("Sentry-Trace: $sentryTrace");
    logger.i("Baggage: $baggage");

    logger.i("firebaseToken: $firebaseToken");
    logger.i("deviceId: $deviceId");

    _sender = Sender(
      firebase: firebaseToken,
      deviceId: deviceId,
      deviceName: model,
      authorization: authorization,
      sentryTrace: sentryTrace,
      baggage: baggage,
    );
  }

  String generateRandomDeviceId() {
    final Random random = Random();
    const String hexChars = '0123456789abcdef';

    // 循环 16 次，每次从 hexChars 中随机取一个字符
    return List.generate(16, (index) => hexChars[random.nextInt(16)]).join();
  }

  String generateFirebaseTokenLikeExample() {
    final Random random = Random();

    // Firebase Token 标准字符集
    const String chars =
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_';

    // 内部辅助函数：生成指定长度的随机字符串
    String getRandomString(int length) {
      return List.generate(
          length, (index) => chars[random.nextInt(chars.length)]).join();
    }

    // 1. 生成第一部分：22位随机字符
    String part1 = getRandomString(22);

    // 2. 生成第二部分：总长 140 位
    // 前缀固定为 "APA91b" (6位)
    String prefix2 = "APA91b";
    // 剩余需要生成的长度 = 140 - 6 = 134 位
    String body2 = getRandomString(134);

    String part2 = "$prefix2$body2";

    // 3. 用冒号拼接
    return "$part1:$part2";
  }

  void _requestOtp() async {
    if (_phoneNumber?.isEmpty ?? true) {
      EasyLoading.showToast('phone number is empty.');
      return;
    }

    if (_password?.isEmpty ?? true) {
      EasyLoading.showToast('phone number is empty.');
      return;
    }

    final phoneNumber = _phoneNumber!;
    final password = _password!;

    EasyLoading.show(status: 'loading...');

    try {
      if (await _sender.sendDeviceInfo() == false) {
        EasyLoading.showToast('send device info fail.');
        return;
      }

      if (await _sender.checkPhone(phone: phoneNumber) == false) {
        EasyLoading.showToast('check phone fail.');
        return;
      }

      final loginRet =
          await _sender.login(phone: phoneNumber, password: password);
      if (loginRet.item1 == false) {
        EasyLoading.showToast('login fail.');
        return;
      }
      if (loginRet.item2) {
        setState(() => _loginStatus = AyaLoginStaus.logined);
        return;
      }

      if (await _sender.getDefaultSMS(phone: phoneNumber) == false) {
        EasyLoading.showToast('get default sms fail.');
        return;
      }

      setState(() => _loginStatus = AyaLoginStaus.requestOtp);

      EasyLoading.showInfo('send auth code success.');
      logger.i('request auth code success');
    } catch (e, stackTrace) {
      logger.e('auth err: $e', stackTrace: stackTrace);
      EasyLoading.showError('request err, code: $e',
          dismissOnTap: true, duration: const Duration(seconds: 60));
      return;
    } finally {
      EasyLoading.dismiss();
    }
  }

  bool _checkInput({bool checkOtp = true}) {
    if (_phoneNumber?.isEmpty ?? true) {
      EasyLoading.showToast('phone number is empty.');
      return false;
    }
    // if (_phoneNumber?.startsWith('0') ?? false) {
    //   EasyLoading.showToast('phone number must remove prefix 0.');
    //   return false;
    // }
    if (_password?.isEmpty ?? true) {
      EasyLoading.showToast('pin is empty.');
      return false;
    }
    if (checkOtp && (_otpCode?.isEmpty ?? true)) {
      EasyLoading.showToast('auth code is empty.');
      return false;
    }
    // if (_token?.isEmpty ?? true) {
    //   EasyLoading.showToast('token is empty.');
    //   return false;
    // }
    // if (_remark?.isEmpty ?? true) {
    //   EasyLoading.showToast('remark is empty.');
    //   return false;
    // }
    return true;
  }

  String qrSerialNo = '';
  String businessUniqueId = '';

  void _verityOTP() async {
    if (!_checkInput()) return;

    final phoneNumber = _phoneNumber!;
    // final id = _id!.toUpperCase();
    final otpCode = _otpCode!;

    EasyLoading.show(status: 'loading...');
    try {
      {
        if (await _sender.loginVerifyOTP(
              phone: phoneNumber,
              otp: otpCode,
            ) ==
            false) {
          EasyLoading.showToast('loginVerifyOTP fail.');
          return;
        }

        // if (await _sender.login(phone: phoneNumber, password: _password!) == false) {
        //   EasyLoading.showToast('login fail.');
        //   return;
        // }

        // {
        //   final balance = await _sender.getBalance();
        //   if (balance == null) {
        //     EasyLoading.showToast('get balance fail.');
        //     return;
        //   }
        // }

        // var needVerifyNrc = false;
        // {
        //   final ret1 = await _sender.finishQRCode(
        //       phoneNumber, qrSerialNo, businessUniqueId);
        //   logger.i('finish qrcode ret: ${ret1.item1}');

        //   needVerifyNrc = ret1.item3?.nextVerifyType == 'NRC';

        //   if (!ret1.item1) return;
        // }

        // if (needVerifyNrc) {
        //   final ret1 =
        //       await _sender.verifyNrc(phoneNumber, businessUniqueId, id);
        //   logger.i('verify nrc ret: ${ret1.item1}');
        //   if (!ret1.item1) return;
        // }

        // {
        //   final ret =
        //       await _sender.loginMsg(phoneNumber, otpCode, businessUniqueId);
        //   if (!ret.item1) {
        //     EasyLoading.showToast('login fail.msg: ${ret.item2}');
        //     logger.i('login fail.msg: ${ret.item2}');
        //     return;
        //   }
        // }

        // {
        //   final ret1 =
        //       await _sender.verifyNrc(phoneNumber, businessUniqueId, id);
        //   logger.i('verify nrc ret: ${ret1.item1}');
        //   if (!ret1.item1) return;
        // }

        // 验证身份证
        // {
        //   final ret = await _sender.identityVerificationMsg(phoneNumber, id);
        //   if (!ret) {
        //     EasyLoading.showToast('identity verification fail.');
        //     logger.i('identity verification fail.');
        //     return;
        //   }
        // }

        // 新设备登录
        // {
        //   final ret = await _sender.newAutoLoginMsg(
        //       phoneNumber, businessUniqueId, false);
        //   if (!ret) {
        //     EasyLoading.showToast('new login fail.');
        //     logger.i('new login fail.');
        //     return;
        //   }
        // }

        // {
        //   final ret2 =
        //       await _sender.loginMsg1(phoneNumber, otpCode, businessUniqueId);
        //   if (!ret2.item1) {
        //     EasyLoading.showToast('login fail 1.');
        //     logger.i('login fail 1.');
        //     return;
        //   }
        //   // res1 = ret2.item3!;
        // }

        // 验证身份证
        // {
        //   final ret = await _sender.identityVerificationMsg(phoneNumber, id);
        //   if (!ret) {
        //     EasyLoading.showToast('identity verification fail.');
        //     logger.i('identity verification fail.');
        //     return;
        //   }
        // }

        // final ret2 = await _sender.newAutoLoginMsg(
        //     phoneNumber, res.businessUniqueId!, false);
        // if (res1?.nrcVerifyEnable == '1') {
        //   // 新设备
        //   _sender.token = res1?.userInfo!.token;

        //   // 验证身份证
        //   {
        //     final ret = await _sender.identityVerificationMsg(phoneNumber, id);
        //     if (!ret) {
        //       EasyLoading.showToast('identity verification fail.');
        //       logger.i('identity verification fail.');
        //       return;
        //     }
        //   }

        //   // // 新设备登录
        //   // {
        //   //   final ret = await _sender.newAutoLoginMsg(phoneNumber, false);
        //   //   if (!ret) {
        //   //     EasyLoading.showToast('new login fail.');
        //   //     logger.i('new login fail.');
        //   //     return;
        //   //   }
        //   // }
        // }

        // // 获取余额
        // {
        //   final ret = await _sender.queryCustomerBalanceMsg(phoneNumber);
        //   if (!ret) {
        //     EasyLoading.showToast('query customer balance fail.');
        //     logger.i('query customer balance fail.');
        //     return;
        //   }
        // }
      }
      setState(() => _loginStatus = AyaLoginStaus.waitOldDeviceAuth);
    } catch (e, stackTrace) {
      logger.e('err: $e', stackTrace: stackTrace);
      EasyLoading.showError('request err, code: $e',
          dismissOnTap: true, duration: const Duration(seconds: 60));
      return;
    } finally {
      EasyLoading.dismiss();
    }
  }

  void _loginWithOldDevice() async {
    if (!_checkInput(checkOtp: false)) return;

    final phoneNumber = _phoneNumber!;
    final password = _password!;

    EasyLoading.show(status: 'loading...');
    try {
      final loginRet =
          await _sender.login(phone: phoneNumber, password: password);
      if (loginRet.item1 == false) {
        EasyLoading.showToast('login fail.');
        return;
      }
      if (loginRet.item2) {
        setState(() => _loginStatus = AyaLoginStaus.logined);
      } else {
        setState(() => _loginStatus = AyaLoginStaus.waitOldDeviceAuth);
      }
    } catch (e, stackTrace) {
      logger.e('err: $e', stackTrace: stackTrace);
      EasyLoading.showError('request err, code: $e',
          dismissOnTap: true, duration: const Duration(seconds: 60));
      return;
    } finally {
      EasyLoading.dismiss();
    }
  }

  void _authBackServer() async {
    if (!_checkInput(checkOtp: false)) return;

    try {
      EasyLoading.show(status: 'loading...');
      {
        // final phoneNumber = _phoneNumber!;
        // final password = _password!;

        // _sender.authorization = 'Basic hQCOKs75uoYxakySqIA7qrjzdj2Z9PYn';
        // final loginRet = await _sender.login(phone: phoneNumber, password: password);
        // if (loginRet.item1 == false) {
        //   EasyLoading.showToast('login fail.');
        //   return;
        // }

        // final balance = await _sender.getBalance();
        //  logger.i('balance: $balance');
        // if (balance == null) {
        //   EasyLoading.showToast('get balance fail.');
        //   return;
        // }

        // final records = await _sender.transHistory(pageParam: 0, start: 0, number: 20);
        // logger.i('records: ${records?.length}');

        final host = _platformsResponseData!.url!.replaceAll('http://', '');
        // const path = 'api/pay/payinfo_apply';
        // const path = 'api/pay/tool_apply';
        const path = 'api/pay/purview_apply';
        final url = Uri.http(host, path, {
          'token': _token,
          'phone': _phoneNumber,
          'platform': 'aya',
          'remark': _remark,
        });
        logger.i('url: ${url.toString()}');
        logger.i('host: $host, path: $path');
        final response = await Future.any([
          http.post(url),
          Future.delayed(const Duration(seconds: 10)),
        ]);

        if (response is! http.Response) {
          EasyLoading.showError('auth timeout');
          logger.i('auth timeout');
          return;
        }

        final body = response.body;
        logger.i('res body: $body');

        final res = ReportGeneralResponse.fromJson(jsonDecode(body));
        if (res.status != 'T') {
          EasyLoading.showError(
              'auth fail. code: ${res.status}, msg: ${res.message}');
          return;
        }
      }
      EasyLoading.show(status: 'wait server auth');

      final host = _platformsResponseData!.url!.replaceAll('http://', '');
      // const path = 'api/pay/payinfo_verify';
      // const path = 'api/pay/tool_verify';
      const path = 'api/pay/purview_verify';
      final url = Uri.http(host, path, {
        'token': _token,
        'phone': _phoneNumber,
        'platform': 'aya',
      });
      logger.i('url: ${url.toString()}');
      logger.i('host: $host, path: $path');
      for (var i = 0; i < 10; ++i) {
        final response = await Future.any([
          http.post(url),
          Future.delayed(const Duration(seconds: 10)),
        ]);

        if (response is! http.Response) {
          EasyLoading.showError('auth timeout');
          logger.i('auth timeout');
          return;
        }

        final body = response.body;
        logger.i('res body: $body');

        final res = ReportGeneralResponse.fromJson(jsonDecode(body));
        if (res.status == 'T') {
          EasyLoading.showInfo('auth success.');
          break;
        }
        if (res.status == 'F') {
          EasyLoading.showError(
              'auth fail. code: ${res.status}, msg: ${res.message}');
          break;
        }
        if (res.status == 'W') {
          await Future.delayed(const Duration(seconds: 3));
        }
      }
      setState(() => _hasAuth = true);
    } catch (e, stackTrace) {
      logger.e('e: $e', stackTrace: stackTrace);
    } finally {
      EasyLoading.dismiss();
    }
  }

  InputDecoration _buildInputDecoration(String hit, IconData icon) {
    return InputDecoration(
      border: const OutlineInputBorder(),
      prefixIcon: Icon(icon, color: Colors.blue),
      labelText: hit,
      hintText: "Input $hit",
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('auth'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 15, 15, 0),
              child: PlatformSelector(
                platforms: widget.platforms,
                onValueChangedCallback: (platform) =>
                    _platformsResponseData = platform,
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 15, 15, 0),
              child: TextFormField(
                controller: TextEditingController()..text = _phoneNumber ?? "",
                onChanged: (value) => _phoneNumber = value.trim(),
                // validator: _validator,
                keyboardType: TextInputType.number,
                decoration: _buildInputDecoration("phone number", Icons.phone),
              ),
            ),
            // Padding(
            //   padding: const EdgeInsets.fromLTRB(15, 15, 15, 0),
            //   child: TextFormField(
            //     controller: TextEditingController()..text = _id ?? "",
            //     onChanged: (value) => _id = value.trim(),
            //     // validator: _validator,
            //     keyboardType: TextInputType.number,
            //     decoration: _buildInputDecoration("id", Icons.password),
            //   ),
            // ),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 15, 15, 15),
              child: TextFormField(
                controller: TextEditingController()..text = _password ?? "",
                onChanged: (value) => _password = value.trim(),
                // validator: _validator,
                keyboardType: TextInputType.number,
                decoration: _buildInputDecoration("password", Icons.password),
              ),
            ),
            OutlinedButton(
                onPressed: _requestOtp, child: const Text('request otp code.')),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 15, 15, 0),
              child: TextFormField(
                controller: TextEditingController()..text = _otpCode ?? "",
                onChanged: (value) => _otpCode = value.trim(),
                // validator: _validator,
                keyboardType: TextInputType.number,
                decoration: _buildInputDecoration("otp code", Icons.security),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 15, 15, 0),
              child: TextFormField(
                controller: TextEditingController()..text = _remark ?? "",
                onChanged: (value) => _remark = value.trim(),
                // validator: _validator,
                keyboardType: TextInputType.text,
                decoration: _buildInputDecoration("remark", Icons.tag),
              ),
            ),
            const Padding(padding: EdgeInsets.only(bottom: 15)),
            Row(
              children: [
                const Spacer(),
                // OutlinedButton(
                //   onPressed: _questQrCode,
                //   // onPressed: _login,
                //   child: const Text('request qr code'),
                // ),
                const Padding(padding: EdgeInsets.only(left: 15, right: 15)),
                OutlinedButton(
                  // onPressed: _hasLogin ? null : _verityOTP,
                  // onPressed: _login,
                  // child: Text(_hasLogin ? 'logined aya' : 'login aya'),
                  onPressed: switch (_loginStatus) {
                    AyaLoginStaus.none => null,
                    AyaLoginStaus.requestOtp => _verityOTP,
                    AyaLoginStaus.waitOldDeviceAuth => _loginWithOldDevice,
                    AyaLoginStaus.logined => null,
                  },
                  child: Text(switch (_loginStatus) {
                    AyaLoginStaus.none => 'Wait Request OTP',
                    AyaLoginStaus.requestOtp => "Auth OTP",
                    AyaLoginStaus.waitOldDeviceAuth =>
                      "Login(Old Device Authed.)",
                    AyaLoginStaus.logined => "Logined",
                  }),
                ),
                const Padding(padding: EdgeInsets.only(left: 15, right: 15)),
                OutlinedButton(
                  onPressed: _hasAuth ? null : _authBackServer,
                  // onPressed: _auth,
                  child: Text(_hasAuth ? 'login report' : 'login report'),
                ),
                const Spacer(),
              ],
            ),
            const Padding(padding: EdgeInsets.fromLTRB(0, 15, 0, 0)),
            OutlinedButton(
              onPressed: (!_hasAuth || _loginStatus != AyaLoginStaus.logined)
                  ? null
                  : () async {
                      if (!context.mounted) return;
                      if (!_checkInput()) return;
                      Navigator.pop(
                        context,
                        AccountData(
                            sender: _sender,
                            token: _token!,
                            remark: _remark!,
                            platformName: _platformsResponseData!.name!,
                            platformUrl: _platformsResponseData!.url!,
                            platformKey: _platformsResponseData!.key!,
                            platformMark: _platformsResponseData!.mark!,
                            phoneNumber: _phoneNumber!,
                            pin: _password!,
                            id: _id!,
                            authCode: _otpCode!,
                            isLogined: true
                            // isWmtMfsInvalid: false,
                            ),
                      );
                    },
              child: const Text('OK'),
            ),
          ],
        ),
      ),
    );
  }
}
